import './globals.css';
export const metadata={title:'PMA Cadet Management',description:'PMA cadet registration, courses, exams and results'};
export default function RootLayout({children}){return <html><body>{children}</body></html>}